const Layout = ({ children }) => {
    return(
      <div className="layout">
        <h2>Header</h2>
        {children}
        <h2>Footer</h2>
      </div>
    );
}
  
export default Layout;
