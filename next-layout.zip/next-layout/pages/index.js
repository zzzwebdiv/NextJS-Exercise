export default function HomePage() {
    return <div>Welcome to Next.js!!</div>
}
